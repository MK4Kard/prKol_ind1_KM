﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind1_9_KM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name_f = textBox1.Text;
            string text = "";

            if (File.Exists(name_f))
            {
                string file = File.ReadAllText(name_f);
                MessageBox.Show(file);

                MessageBox.Show(IVF(file).ToString());

                if (IVF(file))
                {
                    textBox2.Text = file;
                    text = $"Ответ: {Answer(file)}";
                }
                else
                {
                    text = "Формула записана неправильно";
                }
            }
            else
            {
                text = "Такого файла не существует";
            }

            MessageBox.Show(text);
        }

        public static int Answer(string formula)
        {
            Stack<int> values = new Stack<int>();
            Stack<char> operations = new Stack<char>();
            int index = 0;

            while (index < formula.Length)
            {
                char currentChar = formula[index];

                if (char.IsDigit(currentChar))
                {
                    int number = 0;
                    while (index < formula.Length && char.IsDigit(formula[index]))
                    {
                        number = number * 10 + (formula[index] - '0');
                        index++;
                    }
                    values.Push(number); 
                    continue;
                }

                if (currentChar == '(')
                {
                    index++; 
                    continue; 
                }

                if (currentChar == ')')
                {
                    if (operations.Count > 0)
                    {
                        char operation = operations.Pop();
                        int b = values.Pop();
                        int a = values.Pop();

                        if (operation == 'm')
                        {
                            values.Push(a - b); 
                        }
                        else if (operation == 'p')
                        {
                            values.Push((a + b) % 10); 
                        }
                    }
                    index++;
                    continue; 
                }

                if (currentChar == 'm' || currentChar == 'p')
                {
                    operations.Push(currentChar); 
                    index += 2; 
                    continue; 
                }

                index++;
            }

            return values.Pop(); 
        }

        public bool IVF(string file)
        {
            if (string.IsNullOrEmpty(file))
            {
                return false;
            }

            if (!file.All(c => Char.IsDigit(c) || c == '(' || c == ')' || c == ',' || c == 'm' || c == 'p'))
            {
                return false;
            }

            int openBrackets = 0;

            foreach (char c in file)
            {
                if (c == '(')
                {
                    openBrackets++;
                }
                else if (c == ')')
                {
                    openBrackets--;
                    if (openBrackets < 0)
                    {
                        return false;
                    }
                }
            }

            return openBrackets == 0;
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
